# Changelog
_All notable changes to CERiNG standalone files will be documented in this file._

## v0.1 (2022-01-23)

- Add test file